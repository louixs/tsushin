import { createTsushinWidget } from "./src/widget";
const widget = createTsushinWidget({
    compact: true,
    height: 50,
    left: "0%",
    lineWidth: 1,
    showAxisLabels: false,
    showTimeLabels: false,
    top: "92%",
    width: 200,
    widgetDir: "tsushin_small.widget",
});
export const className = widget.className;
export const command = widget.command;
export const initialState = widget.initialState;
export const refreshFrequency = widget.refreshFrequency;
export const render = widget.render;
export const updateState = widget.updateState;
