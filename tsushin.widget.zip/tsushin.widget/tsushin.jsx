import { createTsushinWidget } from "./src/widget";
const widget = createTsushinWidget({
    compact: false,
    height: 250,
    left: "30%",
    lineWidth: 1.75,
    showAxisLabels: true,
    showTimeLabels: true,
    top: "63%",
    width: 400,
    widgetDir: "tsushin.widget",
});
export const className = widget.className;
export const command = widget.command;
export const initialState = widget.initialState;
export const refreshFrequency = widget.refreshFrequency;
export const render = widget.render;
export const updateState = widget.updateState;
